<?php

namespace App\Vendor\Ueditor;

use Hyperf\HttpServer\Contract\RequestInterface as Request;
use App\Vendor\Ueditor\Config\UploadConfig;
use Swoole\Coroutine\System;
use Hyperf\Utils\Context;
use Hyperf\Utils\Filesystem\Filesystem;

/**
 * Created by JetBrains PhpStorm.
 * User: taoqili
 * Date: 12-7-18
 * Time: 上午11: 32
 * UEditor编辑器通用上传类
 */
class Uploader
{

    const UPLOAD_TYPE_UPLOAD = 1;
    const UPLOAD_TYPE_REMOTE = 2;
    const UPLOAD_TYPE_BASE64 = 3;


    /**
     * 构造函数
     * @param string $fileField 表单名称
     * @param array  $config 配置项
     * @param bool   $base64 是否解析base64编码，可省略。若开启，则$fileField代表的是base64编码的字符串表单名
     */
    public function __construct(UploadConfig $config, $fileField, ?Request $request = null, $type = self::UPLOAD_TYPE_UPLOAD,$client=null)
    {
        Context::set('fileField',$fileField);
        Context::set('config',$config);
        Context::set('request',$request);
        Context::set('client',$client);

        switch ($type) {
            case self::UPLOAD_TYPE_UPLOAD:
                $this->upFile();
                break;

            case self::UPLOAD_TYPE_BASE64:
                $this->upBase64();
                break;

            case self::UPLOAD_TYPE_REMOTE:
                $this->saveRemote();
                break;
        }
    }

    /**
     * 上传文件的主处理方法
     * @return mixed
     */
    private function upFile()
    {
        $request = Context::get('request');
        /**
         * @var $file UploadFile
         */

        $file = $request->file(Context::get('fileField'));

        if (!$file) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_FILE_NOT_FOUND"));
            return;
        }

        if ($file->getError() !='0') {
            Context::set('stateInfo',$this->getStateInfo("ERROR_FILE_NOT_FOUND"));
            return;
        }
        Context::set('oriName',$file->getClientFilename());
        Context::set('fileSize',$file->getSize());
        Context::set('fileType',$file->getClientMediaType());
        Context::set('fullName',$this->getFullName());
        Context::set('filePath',$this->getFilePath());
        Context::set('fileName',$this->getFileName());

        $dirname = dirname($this->getFilePath());

        //检查文件大小是否超出限制
        if (!$this->checkSize()) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_SIZE_EXCEED"));
            return;
        }

        //检查是否不允许的文件格式
        if (!$this->checkType()) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_TYPE_NOT_ALLOWED"));
            return;
        }

        $this->createFolders($dirname);
        if(!is_dir($dirname)){
            Context::set('stateInfo',$this->getStateInfo("ERROR_CREATE_DIR"));
        }else if (!is_writeable($dirname)) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_DIR_NOT_WRITEABLE"));
            return;
        }


        //移动文件
        $file->moveTo(Context::get('filePath'));

        if ($file->isMoved()) {
            Context::set('stateInfo',UploadResponse::MAP_ARR[0]);
        }else{
            Context::set('stateInfo',$this->getStateInfo("ERROR_FILE_MOVE"));
        }

    }

    /**
     * 处理base64编码的图片上传
     * @return mixed
     */
    private function upBase64()
    {
        $request = Context::get('request');
        $base64Data = $request->getParsedBody()[Context::get('fileField')];
        $img = base64_decode($base64Data);
        $config = Context::get('config');
        Context::set('oriName',$config->getOriName());
        Context::set('fileSize',strlen($img));
        Context::set('fileType',$this->getFileExt());
        Context::set('fullName',$this->getFullName());
        Context::set('filePath',$this->getFilePath());
        Context::set('fileName',$this->getFileName());

        $dirname = dirname($this->getFilePath());

        //检查文件大小是否超出限制
        if (!$this->checkSize()) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_SIZE_EXCEED"));
            return;
        }

        //创建目录

        $this->createFolders($dirname);
        if(!is_dir($dirname)){
            Context::set('stateInfo',$this->getStateInfo("ERROR_CREATE_DIR"));
        }else if (!is_writeable($dirname)) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_DIR_NOT_WRITEABLE"));
            return;
        }
        $filesystem = new Filesystem();
        $filesystem->append(Context::get('filePath'),$img);

        //是否存在
        if ($filesystem->exists(Context::get('filePath'))) {
            Context::set('stateInfo',UploadResponse::MAP_ARR[0]);
        }else{
            Context::set('stateInfo',$this->getStateInfo("ERROR_FILE_MOVE"));
        }

    }

    /**
     * 拉取远程图片
     * @return mixed
     */
    private function saveRemote()
    {

        $imgUrl = htmlspecialchars(Context::get('fileField'));
        $imgUrl = str_replace("&amp;", "&", $imgUrl);
        $config = Context::get('config');
        //http开头验证
        if (strpos($imgUrl, "http") !== 0) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_HTTP_LINK"));
            return;
        }

        preg_match('/(^https*:\/\/[^:\/]+)/', $imgUrl, $matches);
        $host_with_protocol = count($matches) > 1 ? $matches[1] : '';

        // 判断是否是合法 url
        if (!filter_var($host_with_protocol, FILTER_VALIDATE_URL)) {
            Context::set('stateInfo',$this->getStateInfo("INVALID_URL"));
            return;
        }

        preg_match('/^https*:\/\/(.+)/', $host_with_protocol, $matches);
        $host_without_protocol = count($matches) > 1 ? $matches[1] : '';

//        // 此时提取出来的可能是 ip 也有可能是域名，先获取 ip
        $ip = System::gethostbyname($host_without_protocol);
        // 判断是否是私有 ip
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE)) {
            Context::set('stateInfo',$this->getStateInfo("INVALID_IP"));
            return;
        }

        //获取远程图片
        $options = ['verify'=>false];
        $client = Context::get('client');

        $client = $client->create($options);

        $response = $client->get($imgUrl);

        $img = $response->getBody()->getContents();


        //请求结果判断
        if (!(stristr($response->getStatusCode(), "200"))) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_DEAD_LINK"));
            return;
        }

        //格式验证(扩展名验证和Content-Type验证)
        $fileType = strtolower(strrchr($imgUrl, '.'));

        if (!in_array($fileType, $config->getAllowFiles()) || !isset($response->getHeaders()['content-type']) || !stristr($response->getHeaders()['content-type']['0'], "image")) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_HTTP_CONTENTTYPE"));
            return;
        }

        Context::set('file',$img);

        preg_match("/[\/]([^\/]*)[\.]?[^\.\/]*$/", $imgUrl, $m);

        $oriName = $m ? $m[1] : "";
        Context::set('oriName',$oriName);
        Context::set('fileSize',strlen($img));
        Context::set('fileType',$this->getFileExt());
        Context::set('fullName',$this->getFullName());
        Context::set('filePath',$this->getFilePath());
        Context::set('fileName',$this->getFileName());

        $dirname = dirname($this->getFilePath());

        //检查文件大小是否超出限制
        if (!$this->checkSize()) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_SIZE_EXCEED"));
            return;
        }

        $this->createFolders($dirname);
        if(!is_dir($dirname)){
            Context::set('stateInfo',$this->getStateInfo("ERROR_CREATE_DIR"));
        }else if (!is_writeable($dirname)) {
            Context::set('stateInfo',$this->getStateInfo("ERROR_DIR_NOT_WRITEABLE"));
            return;
        }

        $filesystem = new Filesystem();
        $filesystem->append(Context::get('filePath'),$img);

        //是否存在
        if ($filesystem->exists(Context::get('filePath'))) {
            Context::set('stateInfo',UploadResponse::MAP_ARR[0]);
        }else{
            Context::set('stateInfo',$this->getStateInfo("ERROR_FILE_MOVE"));
        }

    }

    /**
     * 上传错误检查
     * @param $errCode
     * @return string
     */
    private function getStateInfo($errCode)
    {
        return !UploadResponse::MAP_ARR[$errCode] ? UploadResponse::MAP_ARR["ERROR_UNKNOWN"] : UploadResponse::MAP_ARR[$errCode];
    }

    /**
     * 获取文件扩展名
     * @return string
     */
    private function getFileExt()
    {
        $extName = strtolower(strrchr(Context::get('oriName'), '.'));
        return $extName;
    }

    /**
     * 重命名文件
     * @return string
     */
    private function getFullName()
    {
        //替换日期事件
        $t = time();
        $d = explode('-', date("Y-y-m-d-H-i-s"));
        $config = Context::get('config');
        $format = $config->getPathFormat();
        $format = str_replace("{yyyy}", $d[0], $format);
        $format = str_replace("{yy}", $d[1], $format);
        $format = str_replace("{mm}", $d[2], $format);
        $format = str_replace("{dd}", $d[3], $format);
        $format = str_replace("{hh}", $d[4], $format);
        $format = str_replace("{ii}", $d[5], $format);
        $format = str_replace("{ss}", $d[6], $format);
        $format = str_replace("{time}", $t, $format);

        //过滤文件名的非法自负,并替换文件名
        $oriName = substr(Context::get('oriName'), 0, strrpos(Context::get('oriName'), '.'));
        $oriName = preg_replace("/[\|\?\"\<\>\/\*\\\\]+/", '', $oriName);
        $format = str_replace("{filename}", $oriName, $format);

        //替换随机字符串
        $randNum = rand(1, 10000000000) . rand(1, 10000000000);
        if (preg_match("/\{rand\:([\d]*)\}/i", $format, $matches)) {
            $format = preg_replace("/\{rand\:[\d]*\}/i", substr($randNum, 0, $matches[1]), $format);
        }

        $ext = $this->getFileExt();
        return $format . $ext;
    }

    /**
     * 获取文件名
     * @return string
     */
    private function getFileName()
    {
        return substr(Context::get('filePath'), strrpos(Context::get('filePath'), '/') + 1);
    }

    /**
     * 获取文件完整路径
     * @return string
     */
    private function getFilePath()
    {
        $fullName = Context::get('fullName');
        $config = Context::get('config');
        $rootPath = $config->getRootPath();

        if (substr($fullName, 0, 1) != '/') {
            $fullName = '/' . $fullName;
        }

        return $rootPath . $fullName;
    }

    /**
     * 文件类型检测
     * @return bool
     */
    private function checkType()
    {

        $config = Context::get('config');
        return in_array($this->getFileExt(), $config->getAllowFiles());
    }

    /**
     * 文件大小检测
     * @return bool
     */
    private function checkSize()
    {
        $config = Context::get('config');
        return Context::get('fileSize') <= ($config->getMaxSize());
    }

    private function createFolders($dir)
    {
        return is_dir($dir) or ($this->createFolders(dirname($dir)) and mkdir($dir,0777,true));
    }

    /**
     * 获取当前上传成功文件的各项信息
     */
    public function getFileInfo(): UploadResponse
    {
        $response = new UploadResponse();
        $response->setState(Context::get('stateInfo'));
        $response->setUrl(Context::get('fullName'));
        $response->setTitle(Context::get('fileName'));
        $response->setOriginal(Context::get('oriName'));
        $response->setType(Context::get('fileType'));
        $response->setSize(Context::get('fileSize'));
        return $response;
    }

}
