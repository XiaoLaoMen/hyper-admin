<?php

namespace App\Controller;

use App\Controller\Admin\AbstractController;
use Hyperf\Guzzle\ClientFactory;
use Hyperf\Di\Annotation\Inject;
use App\Vendor\Ueditor\Config\CatcherConfig;
use App\Vendor\Ueditor\Ueditor;
use Hyperf\HttpServer\Annotation\Controller;
use Hyperf\HttpServer\Annotation\RequestMapping;
use Hyperf\HttpServer\Annotation\Middleware;
use App\Middleware\RequestMiddleware;
/**
 * @Controller()
 * @Middleware(RequestMiddleware::class)
 */
class UeditorController extends AbstractController
{
    protected $rootPath = BASE_PATH . '/public';

    /**
     * @Inject
     * @var ClientFactory
     */
    protected $client;

    /**
     * @RequestMapping(path="/ueditor/getConfig", methods="get,post")
     */
    public function index()
    {
        $action = $this->request->input('action');
        $list = $this->runAction($action);
        return $this->response->json($list);
    }

    protected function runAction($actionName)
    {
        switch ($actionName) {
            case "config":
                $list = $this->config();
                break;
            case "uploadImage":
                $list = $this->uploadImage();
                break;
            case "uploadScrawl":
                $list = $this->uploadScrawl();
                break;
            case "catchImage":
                $list = $this->catchImage();
                break;
            case "uploadVideo":
                $list = $this->uploadVideo();
                break;
            case "uploadFile":
                $list = $this->uploadFile();
                break;
            case "listImage":
                $list = $this->listImage();
                break;
            case "listFile":
                $list = $this->listFile();
                break;
        }
        return $list;
    }


    protected function catchImage()
    {
        $Ueditor = new Ueditor($this->rootPath);
        $catchImageConfig = new CatcherConfig();
        $field = $catchImageConfig->getCatcherFieldName();
        $remoteList = $this->request->getParsedBody()[$field];
        $result = $Ueditor->catchImage($catchImageConfig, $remoteList,$this->client);
        return $result;
    }

    protected function uploadImage()
    {
        $Ueditor = new Ueditor($this->rootPath);
        $result = $Ueditor->uploadImage($this->request);
        return $result;
    }

    protected function uploadScrawl()
    {
        $Ueditor = new Ueditor($this->rootPath);
        $result = $Ueditor->uploadScrawl($this->request);
        return $result;
    }

    protected function uploadVideo()
    {
        $Ueditor = new Ueditor($this->rootPath);
        $result = $Ueditor->uploadVideo($this->request);
        return $result;
    }

    protected function uploadFile()
    {
        $Ueditor = new Ueditor($this->rootPath);
        $result = $Ueditor->uploadFile($this->request);
        return $result;
    }

    protected function listImage()
    {
        $Ueditor = new Ueditor($this->rootPath);
        $result = $Ueditor->listImage();
        return $result;
    }

    protected function listFile()
    {
        $Ueditor = new Ueditor($this->rootPath);
        $result = $Ueditor->listFile();
        return $result;
    }

    protected function config()
    {
        $Ueditor = new Ueditor($this->rootPath);
        $list = $Ueditor->getConfig();
        return $list;
    }
}
